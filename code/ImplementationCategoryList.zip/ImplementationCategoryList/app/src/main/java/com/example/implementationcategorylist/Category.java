package com.example.implementationcategorylist;


public class Category {
    private String name;
    private String gifUrl;

    public Category(String name, String gifUrl) {
        this.name = name;
        this.gifUrl = gifUrl;
    }

    public String getName() {
        return name;
    }

    public String getGifUrl() {
        return gifUrl;
    }
}

