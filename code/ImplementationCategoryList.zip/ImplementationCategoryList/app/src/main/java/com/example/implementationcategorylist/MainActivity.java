package com.example.implementationcategorylist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Category> categoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ListView listView = findViewById(R.id.categoryListView);

        // Prepare category data
        categoryList = new ArrayList<>();
        categoryList.add(new Category("Sports", "https://media.tenor.com/GUxqvRJKpFAAAAAi/olympics-tokyo.gif"));
        categoryList.add(new Category("Music", "https://cdn.dribbble.com/users/441326/screenshots/3165191/media/45c2723efdf8be2140ff43913cbe8a3f.gif"));
        categoryList.add(new Category("Movies", "https://img1.picmix.com/output/stamp/normal/6/0/6/8/1388606_12e74.gif"));

        // Set custom adapter to the ListView
        CategoryAdapter adapter = new CategoryAdapter(this, categoryList);
        listView.setAdapter(adapter);

        // Handle click events
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Pass data to the next activity
                Category selectedCategory = categoryList.get(position);
                Intent intent = new Intent(MainActivity.this, CategoryDetailActivity.class);
                intent.putExtra("name", selectedCategory.getName());
                intent.putExtra("gifUrl", selectedCategory.getGifUrl());
                startActivity(intent);
            }
        });

    }
}