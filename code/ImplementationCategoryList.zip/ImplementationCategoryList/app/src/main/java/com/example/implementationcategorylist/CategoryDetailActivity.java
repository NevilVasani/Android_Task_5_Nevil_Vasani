package com.example.implementationcategorylist;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;

public class CategoryDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_detail);


        ImageView imageView = findViewById(R.id.categoryDetailGif);
        TextView textView = findViewById(R.id.categoryDetailName);

        // Get data from Intent
        String name = getIntent().getStringExtra("name");
        String gifUrl = getIntent().getStringExtra("gifUrl");

        // Set name and GIF
        textView.setText(name);
        Glide.with(this).load(gifUrl).into(imageView);

    }
}